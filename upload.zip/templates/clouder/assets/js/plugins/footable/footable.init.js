$(document).ready(function() {
	$(function () {
		$('.footable').footable();
	});

// If you require any other breakpoint use bellow function	
	//$('.footable').footable({
		//breakpoints: {
		//phone_p: 320,
		//tablet_p: 768
		//}
	//});	
});